<?php
phpinfo();
 